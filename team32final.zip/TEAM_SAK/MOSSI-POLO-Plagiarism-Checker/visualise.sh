python3 public/scrape.py POLO.txt 2
python3 public/scrape.py MOSS.txt 1 #output-plagiarised
python3 public/create_link_data.py
python3 public/merge_json.py